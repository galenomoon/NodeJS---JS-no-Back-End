const http = require('http'); // definindo minha const

let server = http.createServer((req, res) => { //criando servidor

    console.log('URL: ', req.url);
    console.log('METHOD: ', req.method);
    res.end('OK!');
});

server.listen(3000, '127.0.0.1', () => {

    console.log('servidor rodando!')

})