// NPM | GERENCIADOR DE PACOTES DO NODEJS | [npm install ]
// PACKAGE.JSON | O arquivo package. json é o ponto de partida de qualquer projeto NodeJS. Ele é responsável por descrever o seu projeto, informar as engines (versão do node e do npm), url do repositório, versão do projeto, dependências de produção e de desenvolvimento dentre outras coisas.
// EXPRESS | [npm install express --save]
// NODEMON | Atualiza o servidor automáticamente sem reiniciali manualmente conforme o projeto JS é atualizado | [npm install nodemon -g] (-g for global)

// ===============SERVIDOR COM NODEJS ================== //

const express = require('express'); //carregando módulo do servidor
// definindo minha constante (const)

let app = express(); //Invocando o EXPRESS

//GET | método da rota
app.get('/', (req, res) => { //criando servidor
    //(req) REQUISIÇÃO | (res) RESPOSTA

    res.statusCode = 200; //sinal para o servidor informando sucesso na conexão
    res.setHeader('Content-Type', 'text/html'); //Esse troço "cria" um cabeçalho HTML pra interpretar a linha de baixo
    res.end('<h1>Houston? Can you hear me?</h1>'); //caraca menó, criei html com JS 

});

app.get('/users', (req, res) => {

    res.statusCode = 200; //sinal para o servidor informando sucesso na conexão
    res.setHeader('Content-Type', 'application/json'); //prepara a inter pretação para receber um JSON
    res.json({
        users: [{
            name: 'Galeno',
            email: 'galeno@moon.com',
            id: 21
        }]
    });

})

app.listen(3000, '127.0.0.1', () => { //ouça na porta 3000 no ip 127.0.0.1

    console.log('servidor rodando!')

})