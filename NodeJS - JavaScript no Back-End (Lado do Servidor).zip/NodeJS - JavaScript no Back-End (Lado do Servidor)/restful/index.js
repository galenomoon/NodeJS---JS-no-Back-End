const http = require('http'); //carregando módulo do servidor
// definindo minha constante (const)

let server = http.createServer((req, res) => { //criando servidor

    console.log('URL: ', req.url);
    // Ao acessar o servidor, será apresentado o método e a url
    console.log('METHOD: ', req.method);


    // definindo quais as condições pela URL
    switch (req.url) {

        case '/':
            res.statusCode = 200; //sinal para o servidor informando sucesso na conexão
            res.setHeader('Content-Type', 'text/html'); //Esse troço "cria" um cabeçalho HTML pra interpretar a linha de baixo
            res.end('<h1>Houston? Can you hear me?</h1>'); //caraca menó, criei html com JS 
            break;
        case '/users':
            res.statusCode = 200; //sinal para o servidor informando sucesso na conexão
            res.setHeader('Content-Type', 'application/json'); //prepara a inter pretação para receber um JSON
            res.end(JSON.stringify({
                users: [{
                    name: 'Galeno',
                    email: 'galeno@moon.com',
                    id: 21
                }]
            }));
            break;




    }


});

server.listen(3000, '127.0.0.1', () => { //ouça na porta 3000 no ip 127.0.0.1

    console.log('servidor rodando!')

})