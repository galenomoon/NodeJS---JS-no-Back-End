let express = require('express'); //NESSE EXPRESS HÁ IMPLICITAMENTE O HTTTP
let routes = express.Router();


//GET | método da rota
routes.get('/', (req, res) => { //criando servidor
    //(req) REQUISIÇÃO | (res) RESPOSTA

    res.statusCode = 200; //sinal para o servidor informando sucesso na conexão
    res.setHeader('Content-Type', 'text/html'); //Esse troço "cria" um cabeçalho HTML pra interpretar a linha de baixo
    res.end('<h1>Houston? Can you hear me?</h1>'); //caraca menó, criei html com JS 

});

//EXPORTA O MÓDULO
module.exports = routes;