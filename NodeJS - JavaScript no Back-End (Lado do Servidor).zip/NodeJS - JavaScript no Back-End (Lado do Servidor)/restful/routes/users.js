let NeDB = require('nedb'); //Solicitando NeDB
let db = new NeDB({ //CRIAÇÃO DO BANCO
    filename: 'users.db', //Arquivo criado em Disco
    autoload: true //Carregue-o imediatamente
})

//Exporte para o INDEX a FUNCTION app
module.exports = app => {

    app.get('/users', (req, res) => {

        db.find({}).sort({ name: 1 }).exec((err, users) => {
            //Encontre [db.find({})] por {JSON VAZIO = sem predefinição específica} e os ordene em ordem [.sort({name = 1})] crescente e...
            //[(.exec((err, users))] Execute e tenha os parâmetros caso falhe, e caso dê td certo :D

            if (err) { //em caso de falha:

                console.log(`error: ${err}`);
                res.status(400).json({ error: err }); //reposta pro usuário na tela
            } else {

                res.status(200).json(users);
                res.setHeader('Content-Type', 'application/json'); //prepara a inter pretação para receber um JSON
                res.json({
                    users
                });
            }
        })

    });

    app.post('/users', (req, res) => {

        //(err, user) => [Objeto que quero salvar], [funciton](no caso de uma falha)
        db.insert(req.body, (err, user) => { //insira um JSON
            //armazene no banco um JSON

            if (err) { //em caso de falha:

                console.log(`error: ${err}`);
                res.status(400).json({ error: err }); //reposta pro servidor
            } else {

                res.status(200).json(user);
            }

        })

    });
}