module.exports = app => {

    app.get('/users', (req, res) => {

        res.statusCode = 200; //sinal para o servidor informando sucesso na conexão
        res.setHeader('Content-Type', 'application/json'); //prepara a inter pretação para receber um JSON
        res.json({
            users: [{
                name: 'Galeno',
                email: 'galeno@moon.com',
                id: 21
            }]
        });
    });

    app.post('/users', (req, res) => {

        res.json(req.body);

    });
}