const { Router } = require('express');
let express = require('express'); //NESSE EXPRESS HÁ IMPLICITAMENTE O HTTTP
let routes = express.Router();

//
routes.get('/', (req, res) => {

    res.statusCode = 200; //sinal para o servidor informando sucesso na conexão
    res.setHeader('Content-Type', 'application/json'); //prepara a inter pretação para receber um JSON
    res.json({
        users: [{
            name: 'Galeno',
            email: 'galeno@moon.com',
            id: 21
        }]
    });

})

routes.get('/admin', (req, res) => {

    res.statusCode = 200; //sinal para o servidor informando sucesso na conexão
    res.setHeader('Content-Type', 'application/json'); //prepara a inter pretação para receber um JSON
    res.json({
        users: []
    });

})

//EXPORTA O MÓDULO
module.exports = routes;