let NeDB = require('nedb'); //Solicitando NeDB
let db = new NeDB({ //CRIAÇÃO DO BANCO
    filename: 'users.db', //Arquivo criado em Disco
    autoload: true //Carregue-o imediatamente
})


module.exports = app => {

    app.get('/users', (req, res) => {

        res.statusCode = 200; //sinal para o servidor informando sucesso na conexão
        res.setHeader('Content-Type', 'application/json'); //prepara a inter pretação para receber um JSON
        res.json({
            users: [{
                name: 'Galeno',
                email: 'galeno@moon.com',
                id: 21
            }]
        });
    });

    app.post('/users', (req, res) => {

        //(err, user) => [Objeto que quero salvar], [funciton](no caso de uma falha)
        db.insert(req.body, (err, user) => { //insira um JSON
            //armazene no banco um JSON

            if (err) { //em saco de falha:

                console.log(`error: ${err}`);
                res.status(400).json({ error: err }); //reposta pro servidor
            } else {

                res.status(200).json(user);


            }

        })

    });
}